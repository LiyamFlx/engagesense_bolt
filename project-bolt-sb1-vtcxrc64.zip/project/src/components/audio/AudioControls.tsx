import React from 'react';
import { Mic, Square, Upload } from 'lucide-react';

interface AudioControlsProps {
  isRecording: boolean;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export const AudioControls: React.FC<AudioControlsProps> = ({
  isRecording,
  onStartRecording,
  onStopRecording,
  onFileUpload,
}) => (
  <div className="flex gap-4">
    <button
      onClick={isRecording ? onStopRecording : onStartRecording}
      className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
        isRecording
          ? 'bg-red-500 hover:bg-red-600 text-white'
          : 'bg-green-500 hover:bg-green-600 text-white'
      }`}
    >
      {isRecording ? (
        <>
          <Square className="w-5 h-5" />
          Stop Recording
        </>
      ) : (
        <>
          <Mic className="w-5 h-5" />
          Start Recording
        </>
      )}
    </button>
    <label className="flex items-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg cursor-pointer font-medium transition-colors">
      <Upload className="w-5 h-5" />
      Upload Audio
      <input
        type="file"
        accept="audio/*"
        onChange={onFileUpload}
        className="hidden"
      />
    </label>
  </div>
);