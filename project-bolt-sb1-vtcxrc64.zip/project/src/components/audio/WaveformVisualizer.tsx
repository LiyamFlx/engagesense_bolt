import React, { useEffect, useRef } from 'react';
import WaveSurfer from 'wavesurfer.js';

interface WaveformVisualizerProps {
  isRecording: boolean;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({ isRecording }) => {
  const waveformRef = useRef<HTMLDivElement>(null);
  const wavesurferRef = useRef<WaveSurfer | null>(null);

  useEffect(() => {
    if (waveformRef.current) {
      wavesurferRef.current = WaveSurfer.create({
        container: waveformRef.current,
        waveColor: '#4ade80',
        progressColor: '#22c55e',
        cursorColor: '#22c55e',
        height: 100,
        normalize: true,
        interact: false,
      });
    }

    return () => {
      wavesurferRef.current?.destroy();
    };
  }, []);

  return (
    <div
      ref={waveformRef}
      className="w-full h-24 bg-gray-800 rounded-lg overflow-hidden"
    />
  );
};