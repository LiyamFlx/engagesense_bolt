import React from 'react';
import { MetricCard } from './MetricCard';
import { MetricsChart } from './MetricsChart';
import type { EngagementMetricsData } from '../../types/metrics';

interface EngagementMetricsProps extends EngagementMetricsData {}

export const EngagementMetrics: React.FC<EngagementMetricsProps> = (metrics) => {
  return (
    <div className="w-full max-w-3xl mx-auto mt-8">
      <div className="grid grid-cols-2 gap-4 mb-8">
        <MetricCard
          title="Physical"
          value={metrics.physical}
          color="text-green-400"
        />
        <MetricCard
          title="Emotional"
          value={metrics.emotional}
          color="text-blue-400"
        />
        <MetricCard
          title="Mental"
          value={metrics.mental}
          color="text-purple-400"
        />
        <MetricCard
          title="Spiritual"
          value={metrics.spiritual}
          color="text-yellow-400"
        />
      </div>
      <MetricsChart metrics={metrics} />
    </div>
  );
};