import React, { useState } from 'react';
import { Header } from './components/layout/Header';
import { AudioRecorder } from './components/audio/AudioRecorder';
import { EngagementMetrics } from './components/metrics/EngagementMetrics';
import type { EngagementMetricsData } from './types/metrics';

function App() {
  const [metrics, setMetrics] = useState<EngagementMetricsData>({
    physical: 0,
    emotional: 0,
    mental: 0,
    spiritual: 0,
  });

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <Header />
        <AudioRecorder onAudioData={setMetrics} />
        <EngagementMetrics {...metrics} />
      </div>
    </div>
  );
}

export default App;