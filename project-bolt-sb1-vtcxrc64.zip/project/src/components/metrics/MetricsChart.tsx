import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import type { EngagementMetricsData } from '../../types/metrics';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface MetricsChartProps {
  metrics: EngagementMetricsData;
}

export const MetricsChart: React.FC<MetricsChartProps> = ({ metrics }) => {
  const data = {
    labels: ['Physical', 'Emotional', 'Mental', 'Spiritual'],
    datasets: [
      {
        label: 'Engagement Metrics',
        data: Object.values(metrics),
        fill: true,
        borderColor: '#4ade80',
        backgroundColor: 'rgba(74, 222, 128, 0.2)',
        tension: 0.4,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Engagement Analysis',
        color: '#fff',
      },
    },
    scales: {
      r: {
        min: 0,
        max: 100,
        ticks: {
          color: '#fff',
        },
      },
    },
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <Line data={data} options={options} />
    </div>
  );
};