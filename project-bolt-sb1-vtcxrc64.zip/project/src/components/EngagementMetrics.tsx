import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface EngagementMetricsProps {
  physical: number;
  emotional: number;
  mental: number;
  spiritual: number;
}

export const EngagementMetrics: React.FC<EngagementMetricsProps> = ({
  physical,
  emotional,
  mental,
  spiritual,
}) => {
  const data = {
    labels: ['Physical', 'Emotional', 'Mental', 'Spiritual'],
    datasets: [
      {
        label: 'Engagement Metrics',
        data: [physical, emotional, mental, spiritual],
        fill: true,
        borderColor: '#4ade80',
        backgroundColor: 'rgba(74, 222, 128, 0.2)',
        tension: 0.4,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Engagement Analysis',
        color: '#fff',
      },
    },
    scales: {
      r: {
        min: 0,
        max: 100,
        ticks: {
          color: '#fff',
        },
      },
    },
  };

  return (
    <div className="w-full max-w-3xl mx-auto mt-8">
      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-200 mb-2">Physical</h3>
          <div className="text-3xl font-bold text-green-400">{physical}%</div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-200 mb-2">Emotional</h3>
          <div className="text-3xl font-bold text-blue-400">{emotional}%</div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-200 mb-2">Mental</h3>
          <div className="text-3xl font-bold text-purple-400">{mental}%</div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-200 mb-2">Spiritual</h3>
          <div className="text-3xl font-bold text-yellow-400">{spiritual}%</div>
        </div>
      </div>
      <div className="bg-gray-800 p-6 rounded-lg">
        <Line data={data} options={options} />
      </div>
    </div>
  );
};