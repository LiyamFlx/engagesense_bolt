export interface EngagementMetricsData {
  physical: number;
  emotional: number;
  mental: number;
  spiritual: number;
}

export interface AudioData {
  blob: Blob;
  type: string;
}

export interface AudioFeatures {
  rms: number;
  spectralCentroid: number;
  pitch: number;
  zeroCrossingRate: number;
}

export interface SentimentScore {
  positive: number;
  neutral: number;
  negative: number;
}

export interface AnalysisState {
  isAnalyzing: boolean;
  progress: number;
  error: string | null;
}