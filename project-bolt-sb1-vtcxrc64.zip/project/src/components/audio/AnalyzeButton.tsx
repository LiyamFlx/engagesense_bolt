import React from 'react';
import { Activity } from 'lucide-react';
import type { AnalysisState } from '../../types/metrics';

interface AnalyzeButtonProps {
  onAnalyze: () => void;
  disabled: boolean;
  analysisState: AnalysisState;
}

export const AnalyzeButton: React.FC<AnalyzeButtonProps> = ({
  onAnalyze,
  disabled,
  analysisState,
}) => {
  const { isAnalyzing, progress, error } = analysisState;

  return (
    <div className="flex flex-col items-center gap-2">
      <button
        onClick={onAnalyze}
        disabled={disabled || isAnalyzing}
        className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
          disabled || isAnalyzing
            ? 'bg-gray-600 cursor-not-allowed'
            : 'bg-purple-500 hover:bg-purple-600'
        } text-white`}
      >
        <Activity className={`w-5 h-5 ${isAnalyzing ? 'animate-spin' : ''}`} />
        {isAnalyzing ? 'Analyzing...' : 'Analyze Audio'}
      </button>
      {isAnalyzing && (
        <div className="w-full max-w-xs bg-gray-700 rounded-full h-2.5">
          <div
            className="bg-purple-500 h-2.5 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
      {error && <p className="text-red-400 text-sm">{error}</p>}
    </div>
  );
}