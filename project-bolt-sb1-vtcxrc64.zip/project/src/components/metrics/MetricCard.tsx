import React from 'react';

interface MetricCardProps {
  title: string;
  value: number;
  color: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({ title, value, color }) => (
  <div className="bg-gray-800 p-6 rounded-lg">
    <h3 className="text-lg font-medium text-gray-200 mb-2">{title}</h3>
    <div className={`text-3xl font-bold ${color}`}>{value.toFixed(1)}%</div>
  </div>
);