import React, { useState } from 'react';
import { AudioControls } from './AudioControls';
import { WaveformVisualizer } from './WaveformVisualizer';
import { AnalyzeButton } from './AnalyzeButton';
import { extractAudioFeatures, analyzeSentiment, calculateEngagementScores } from '../../utils/audioAnalysis';
import type { AudioData, AnalysisState, EngagementMetricsData } from '../../types/metrics';

interface AudioRecorderProps {
  onAudioData: (metrics: EngagementMetricsData) => void;
}

export const AudioRecorder: React.FC<AudioRecorderProps> = ({ onAudioData }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [analysisState, setAnalysisState] = useState<AnalysisState>({
    isAnalyzing: false,
    progress: 0,
    error: null,
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
      };

      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      setAnalysisState(prev => ({
        ...prev,
        error: 'Error accessing microphone. Please check permissions.',
      }));
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAudioBlob(file);
    }
  };

  const handleAnalyze = async () => {
    if (!audioBlob) return;

    setAnalysisState({
      isAnalyzing: true,
      progress: 0,
      error: null,
    });

    try {
      // Convert blob to AudioBuffer
      const arrayBuffer = await audioBlob.arrayBuffer();
      const audioContext = new AudioContext();
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

      setAnalysisState(prev => ({ ...prev, progress: 30 }));

      // Extract audio features
      const features = await extractAudioFeatures(audioBuffer);
      setAnalysisState(prev => ({ ...prev, progress: 60 }));

      // Analyze sentiment
      const sentiment = await analyzeSentiment(features);
      setAnalysisState(prev => ({ ...prev, progress: 90 }));

      // Calculate final engagement scores
      const engagementScores = calculateEngagementScores(features, sentiment);
      
      setAnalysisState(prev => ({ ...prev, progress: 100 }));
      onAudioData(engagementScores);

      // Reset analysis state after a brief delay to show 100% completion
      setTimeout(() => {
        setAnalysisState({
          isAnalyzing: false,
          progress: 0,
          error: null,
        });
      }, 500);

    } catch (error) {
      console.error('Analysis error:', error);
      setAnalysisState({
        isAnalyzing: false,
        progress: 0,
        error: 'Error analyzing audio. Please try again.',
      });
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="flex flex-col items-center gap-6">
        <AudioControls
          isRecording={isRecording}
          onStartRecording={startRecording}
          onStopRecording={stopRecording}
          onFileUpload={handleFileUpload}
        />
        <WaveformVisualizer isRecording={isRecording} />
        <AnalyzeButton
          onAnalyze={handleAnalyze}
          disabled={!audioBlob || isRecording}
          analysisState={analysisState}
        />
      </div>
    </div>
  );
};